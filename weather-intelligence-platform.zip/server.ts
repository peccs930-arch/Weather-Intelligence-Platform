import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Simple cache for weather search results to prevent rate limiting
const cache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 10 * 60 * 1000; // 10 minutes cache

// Lazy initialized Gemini client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

const app = express();
const PORT = 3000;

app.use(express.json());

// API Endpoints
app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

// Geocoding & Weather Search
app.get("/api/weather/search", async (req, res) => {
  try {
    const query = req.query.q as string;
    if (!query || query.length < 2) {
      return res.json({ results: [] });
    }

    const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=8&language=en&format=json`;
    const response = await fetch(geoUrl);
    if (!response.ok) {
      throw new Error("Geocoding failed");
    }
    const data = await response.json();
    res.json({ results: data.results || [] });
  } catch (error: any) {
    console.error("Geocoding search error:", error);
    res.status(500).json({ error: error.message });
  }
});

// Fetch detailed weather forecast and air quality for a latitude/longitude
app.get("/api/weather/forecast", async (req, res) => {
  try {
    const lat = req.query.lat as string;
    const lon = req.query.lon as string;
    const cityName = (req.query.city as string) || "Detected Location";

    if (!lat || !lon) {
      return res.status(400).json({ error: "Latitude and Longitude are required" });
    }

    const cacheKey = `${lat}_${lon}`;
    const cached = cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      return res.json(cached.data);
    }

    // 1. Fetch Forecast from Open-Meteo
    const forecastParams = new URLSearchParams({
      latitude: lat,
      longitude: lon,
      current: [
        "temperature_2m",
        "relative_humidity_2m",
        "apparent_temperature",
        "is_day",
        "precipitation",
        "rain",
        "showers",
        "snowfall",
        "weather_code",
        "cloud_cover",
        "pressure_msl",
        "wind_speed_10m",
        "wind_direction_10m",
      ].join(","),
      hourly: [
        "temperature_2m",
        "relative_humidity_2m",
        "apparent_temperature",
        "precipitation_probability",
        "precipitation",
        "weather_code",
        "pressure_msl",
        "visibility",
        "wind_speed_10m",
        "uv_index",
        "dew_point_2m",
      ].join(","),
      daily: [
        "weather_code",
        "temperature_2m_max",
        "temperature_2m_min",
        "apparent_temperature_max",
        "apparent_temperature_min",
        "sunrise",
        "sunset",
        "uv_index_max",
        "precipitation_sum",
        "precipitation_probability_max",
        "wind_speed_10m_max",
      ].join(","),
      timezone: "auto",
      forecast_days: "14",
    });

    const forecastUrl = `https://api.open-meteo.com/v1/forecast?${forecastParams.toString()}`;
    const forecastRes = await fetch(forecastUrl);
    if (!forecastRes.ok) {
      throw new Error(`Open-Meteo forecast failed with status: ${forecastRes.status}`);
    }
    const forecastData = await forecastRes.json();

    // 2. Fetch Air Quality from Open-Meteo
    const aqParams = new URLSearchParams({
      latitude: lat,
      longitude: lon,
      current: ["european_aqi", "us_aqi", "pm10", "pm2_5", "carbon_monoxide", "nitrogen_dioxide", "sulphur_dioxide", "ozone"].join(","),
      timezone: "auto",
    });
    const aqUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?${aqParams.toString()}`;
    const aqRes = await fetch(aqUrl);
    const aqData = aqRes.ok ? await aqRes.json() : null;

    const mergedData = {
      cityName,
      latitude: parseFloat(lat),
      longitude: parseFloat(lon),
      forecast: forecastData,
      airQuality: aqData,
      fetchedAt: Date.now(),
    };

    cache.set(cacheKey, { data: mergedData, timestamp: Date.now() });
    res.json(mergedData);
  } catch (error: any) {
    console.error("Forecast fetch error:", error);
    res.status(500).json({ error: error.message });
  }
});

// AI Insights Generator powered by Gemini 3.5 Flash
app.post("/api/weather/ai-insights", async (req, res) => {
  try {
    const { weatherData } = req.body;
    if (!weatherData) {
      return res.status(400).json({ error: "Weather data is required" });
    }

    const ai = getGeminiClient();

    const systemPrompt = `You are a world-class futuristic weather intelligence AI. Analyze the weather data provided and generate precise, highly detailed insights in structured JSON.

Provide recommendations on clothes, travel, outdoor activities, health alerts, farming/gardening advice, and any disaster or severe weather alerts (e.g. heatwave, storm, rain). Make your tone professional, authoritative, but futuristic and engaging.`;

    const userPrompt = `Weather Data for ${weatherData.cityName}:
Current temperature: ${weatherData.forecast?.current?.temperature_2m}°C, Apparent: ${weatherData.forecast?.current?.apparent_temperature}°C
Humidity: ${weatherData.forecast?.current?.relative_humidity_2m}%
Wind: ${weatherData.forecast?.current?.wind_speed_10m} km/h
Weather Code: ${weatherData.forecast?.current?.weather_code}
US Air Quality Index: ${weatherData.airQuality?.current?.us_aqi ?? "Unknown"}
UV Index: ${weatherData.forecast?.daily?.uv_index_max?.[0] ?? "Unknown"}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: {
              type: Type.STRING,
              description: "A 2-3 sentence futuristic summary of the current and upcoming weather.",
            },
            clothing: {
              type: Type.STRING,
              description: "Detailed recommendation of what to wear today.",
            },
            travel: {
              type: Type.STRING,
              description: "Travel assessment (safe, caution, or delayed) with helpful guidelines.",
            },
            health: {
              type: Type.STRING,
              description: "Health recommendations (e.g., UV protection, hydration, allergen warnings).",
            },
            farming: {
              type: Type.STRING,
              description: "Futuristic farming, gardening, or agricultural recommendations.",
            },
            outdoorActivities: {
              type: Type.STRING,
              description: "Assess outdoor fitness/jogging safety and list recommended activities.",
            },
            disasterWarning: {
              type: Type.STRING,
              description: "Severe weather alerts, natural disaster warnings, or safety precautions. Empty if no issues.",
            },
            personalizedReport: {
              type: Type.STRING,
              description: "A brief personalized daily greeting and forecast story.",
            },
          },
          required: [
            "summary",
            "clothing",
            "travel",
            "health",
            "farming",
            "outdoorActivities",
            "disasterWarning",
            "personalizedReport",
          ],
        },
      },
    });

    const jsonStr = response.text?.trim() || "{}";
    const insights = JSON.parse(jsonStr);
    res.json(insights);
  } catch (error: any) {
    console.error("Gemini AI insights error:", error);
    res.status(500).json({ error: error.message });
  }
});

// Curated weather and disaster newsfeed API (synthetic highly-realistic feeds + live global hazards context)
app.get("/api/weather/news", (req, res) => {
  const mockNews = [
    {
      id: "news-1",
      title: "Atmospheric River system to bring heavy rainfall to Western Coastline",
      category: "Storm Tracking",
      severity: "high",
      summary: "Meteorologists monitor a category-4 atmospheric river system expected to make landfall over the next 48 hours, bringing up to 10 inches of rain in mountainous regions.",
      time: "20 mins ago",
      source: "Global Weather Intelligence",
    },
    {
      id: "news-2",
      title: "M 6.4 Earthquake recorded in Pacific Rim; tsunami warnings evaluated",
      category: "Earthquake Feed",
      severity: "critical",
      summary: "A powerful magnitude 6.4 earthquake occurred at a depth of 10 km. Early alert systems deployed warnings across coastal communities. Tsunami advisory remains active.",
      time: "1 hour ago",
      source: "Seismic Alert Network",
    },
    {
      id: "news-3",
      title: "Geomagnetic Solar Storm (G3) threatens grid stability, triggers aurora borealis",
      category: "Space Weather",
      severity: "medium",
      summary: "Solar flare eruptions have directed a coronal mass ejection towards Earth. Ionosphere warnings issued for high-frequency satellite links.",
      time: "3 hours ago",
      source: "Solar Dynamics Lab",
    },
    {
      id: "news-4",
      title: "Record Heatwave expands across Central Europe and North Africa",
      category: "Heatwave Alerts",
      severity: "high",
      summary: "An expansive high-pressure heat dome triggers extreme heat alerts across multiple countries with projected highs touching 43°C.",
      time: "5 hours ago",
      source: "Climate Monitor Unit",
    },
    {
      id: "news-5",
      title: "Super Typhoon 'Vanguard' forms in Western Pacific, paths evaluated",
      category: "Cyclone Alerts",
      severity: "critical",
      summary: "Winds peaking at 220 km/h position Typhoon Vanguard on a northwestern trajectory. Coastal warning flags are currently raised.",
      time: "8 hours ago",
      source: "Tropical Storm Center",
    },
  ];
  res.json({ news: mockNews });
});

// Vite Middleware Setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
