export interface CurrentWeatherData {
  temperature_2m: number;
  relative_humidity_2m: number;
  apparent_temperature: number;
  is_day: number;
  precipitation: number;
  rain: number;
  showers: number;
  snowfall: number;
  weather_code: number;
  cloud_cover: number;
  pressure_msl: number;
  wind_speed_10m: number;
  wind_direction_10m: number;
}

export interface HourlyForecastData {
  time: string[];
  temperature_2m: number[];
  relative_humidity_2m: number[];
  apparent_temperature: number[];
  precipitation_probability: number[];
  precipitation: number[];
  weather_code: number[];
  pressure_msl: number[];
  visibility: number[];
  wind_speed_10m: number[];
  uv_index: number[];
  dew_point_2m: number[];
}

export interface DailyForecastData {
  time: string[];
  weather_code: number[];
  temperature_2m_max: number[];
  temperature_2m_min: number[];
  apparent_temperature_max: number[];
  apparent_temperature_min: number[];
  sunrise: string[];
  sunset: string[];
  uv_index_max: number[];
  precipitation_sum: number[];
  precipitation_probability_max: number[];
  wind_speed_10m_max: number[];
}

export interface AirQualityData {
  current: {
    european_aqi: number;
    us_aqi: number;
    pm10: number;
    pm2_5: number;
    carbon_monoxide: number;
    nitrogen_dioxide: number;
    sulphur_dioxide: number;
    ozone: number;
  };
}

export interface WeatherData {
  cityName: string;
  latitude: number;
  longitude: number;
  forecast: {
    current: CurrentWeatherData;
    hourly: HourlyForecastData;
    daily: DailyForecastData;
  };
  airQuality: AirQualityData | null;
  fetchedAt: number;
}

export interface AIInsights {
  summary: string;
  clothing: string;
  travel: string;
  health: string;
  farming: string;
  outdoorActivities: string;
  disasterWarning: string;
  personalizedReport: string;
}

export interface WeatherNewsItem {
  id: string;
  title: string;
  category: string;
  severity: "low" | "medium" | "high" | "critical";
  summary: string;
  time: string;
  source: string;
}

export interface UserSettings {
  units: "metric" | "imperial";
  language: "en" | "es" | "fr" | "jp";
  theme: "quantum-slate" | "neon-cyber" | "matrix-green";
  accessibility: boolean;
}

export const PRESET_CITIES = [
  { name: "Chennai", lat: 13.0827, lon: 80.2707, country: "India" },
  { name: "New York", lat: 40.7128, lon: -74.006, country: "United States" },
  { name: "London", lat: 51.5074, lon: -0.1278, country: "United Kingdom" },
  { name: "Tokyo", lat: 35.6762, lon: 139.6503, country: "Japan" },
  { name: "Paris", lat: 48.8566, lon: 2.3522, country: "France" },
  { name: "Dubai", lat: 25.2048, lon: 55.2708, country: "United Arab Emirates" },
];

export const WEATHER_CODE_MAP: Record<number, { label: string; icon: string; bg: string }> = {
  0: { label: "Clear Sky", icon: "Sun", bg: "from-amber-500/20 to-orange-500/5" },
  1: { label: "Mainly Clear", icon: "SunDim", bg: "from-amber-400/20 to-yellow-600/5" },
  2: { label: "Partly Cloudy", icon: "CloudSun", bg: "from-sky-400/20 to-blue-600/5" },
  3: { label: "Overcast", icon: "Cloud", bg: "from-slate-500/20 to-slate-700/5" },
  45: { label: "Foggy", icon: "CloudFog", bg: "from-zinc-500/20 to-zinc-700/5" },
  48: { label: "Depositing Rime Fog", icon: "CloudFog", bg: "from-zinc-600/20 to-zinc-800/5" },
  51: { label: "Light Drizzle", icon: "CloudDrizzle", bg: "from-blue-400/20 to-indigo-600/5" },
  53: { label: "Moderate Drizzle", icon: "CloudDrizzle", bg: "from-blue-500/20 to-indigo-700/5" },
  55: { label: "Dense Drizzle", icon: "CloudDrizzle", bg: "from-blue-600/20 to-indigo-800/5" },
  56: { label: "Light Freezing Drizzle", icon: "CloudSnow", bg: "from-teal-400/20 to-cyan-600/5" },
  57: { label: "Dense Freezing Drizzle", icon: "CloudSnow", bg: "from-teal-500/20 to-cyan-700/5" },
  61: { label: "Slight Rain", icon: "CloudRain", bg: "from-blue-400/20 to-blue-700/5" },
  63: { label: "Moderate Rain", icon: "CloudRain", bg: "from-blue-500/20 to-blue-800/5" },
  65: { label: "Heavy Rain", icon: "CloudRainWind", bg: "from-indigo-600/25 to-blue-900/10" },
  66: { label: "Light Freezing Rain", icon: "CloudRainWind", bg: "from-teal-500/20 to-blue-900/5" },
  67: { label: "Heavy Freezing Rain", icon: "CloudRainWind", bg: "from-teal-600/25 to-blue-950/10" },
  71: { label: "Slight Snowfall", icon: "CloudSnow", bg: "from-cyan-400/20 to-slate-600/5" },
  73: { label: "Moderate Snowfall", icon: "CloudSnow", bg: "from-cyan-500/25 to-slate-700/5" },
  75: { label: "Heavy Snowfall", icon: "Snowflake", bg: "from-cyan-300/30 to-blue-100/10" },
  77: { label: "Snow Grains", icon: "Snowflake", bg: "from-cyan-200/20 to-slate-500/5" },
  80: { label: "Slight Rain Showers", icon: "CloudRain", bg: "from-sky-500/20 to-blue-800/5" },
  81: { label: "Moderate Rain Showers", icon: "CloudRain", bg: "from-sky-600/25 to-blue-900/5" },
  82: { label: "Violent Rain Showers", icon: "CloudRainWind", bg: "from-violet-600/30 to-blue-950/10" },
  85: { label: "Slight Snow Showers", icon: "CloudSnow", bg: "from-cyan-500/20 to-sky-700/5" },
  86: { label: "Heavy Snow Showers", icon: "Snowflake", bg: "from-cyan-400/30 to-sky-900/10" },
  95: { label: "Thunderstorm", icon: "CloudLightning", bg: "from-amber-600/25 to-purple-950/15" },
  96: { label: "Thunderstorm with Hail", icon: "CloudLightning", bg: "from-red-600/20 to-purple-950/20" },
  99: { label: "Severe Thunderstorm & Hail", icon: "CloudLightning", bg: "from-red-700/30 to-violet-950/25" },
};
