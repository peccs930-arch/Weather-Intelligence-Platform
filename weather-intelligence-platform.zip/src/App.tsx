import React, { useState, useEffect, useRef } from "react";
import {
  WeatherData,
  AIInsights,
  WeatherNewsItem,
  UserSettings,
  PRESET_CITIES,
  WEATHER_CODE_MAP,
} from "./types";
import BackgroundParticles from "./components/BackgroundParticles";
import WeatherCharts from "./components/WeatherCharts";
import WeatherMap from "./components/WeatherMap";
import NewsFeed from "./components/NewsFeed";
import AiAdvisor from "./components/AiAdvisor";
import {
  Sun,
  SunDim,
  CloudSun,
  Cloud,
  CloudFog,
  CloudDrizzle,
  CloudRain,
  CloudRainWind,
  CloudSnow,
  Snowflake,
  CloudLightning,
  Search,
  Mic,
  Navigation,
  Heart,
  Settings,
  Accessibility,
  Globe,
  Sparkles,
  Cpu,
  Thermometer,
  Droplets,
  Wind,
  Gauge,
  Eye,
  Sunrise,
  Sunset,
  Plus,
  Trash2,
  Volume2,
  VolumeX,
  Languages,
  Activity,
  CalendarDays,
  ShieldAlert,
  Info,
  X,
  ArrowRight,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// Speech Recognition typings
const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

export default function App() {
  // --- States ---
  const [settings, setSettings] = useState<UserSettings>(() => {
    const saved = localStorage.getItem("weather-settings");
    if (saved) return JSON.parse(saved);
    return {
      units: "metric",
      language: "en",
      theme: "quantum-slate",
      accessibility: false,
    };
  });

  const [currentCity, setCurrentCity] = useState({
    name: "Chennai",
    lat: 13.0827,
    lon: 80.2707,
  });

  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [recentSearches, setRecentSearches] = useState<any[]>(() => {
    const saved = localStorage.getItem("weather-recent-searches");
    return saved ? JSON.parse(saved) : [];
  });

  const [favorites, setFavorites] = useState<any[]>(() => {
    const saved = localStorage.getItem("weather-favorites");
    return saved ? JSON.parse(saved) : PRESET_CITIES;
  });

  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [aiInsights, setAiInsights] = useState<AIInsights | null>(null);
  const [news, setNews] = useState<WeatherNewsItem[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [insightsLoading, setInsightsLoading] = useState(false);
  const [newsLoading, setNewsLoading] = useState(true);
  const [voiceActive, setVoiceActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  const autocompleteRef = useRef<HTMLDivElement | null>(null);

  // --- Effects ---
  // Persist configurations
  useEffect(() => {
    localStorage.setItem("weather-settings", JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem("weather-favorites", JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem("weather-recent-searches", JSON.stringify(recentSearches));
  }, [recentSearches]);

  // Handle autocomplete clickaway
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (autocompleteRef.current && !autocompleteRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Primary trigger: Fetch Weather Data when coordinates change
  useEffect(() => {
    fetchWeather(currentCity.lat, currentCity.lon, currentCity.name);
  }, [currentCity]);

  // Trigger: Fetch severe weather news feed on mount
  useEffect(() => {
    fetchNews();
  }, []);

  // Autocomplete debouncing
  useEffect(() => {
    if (searchQuery.trim().length < 2) {
      setSearchResults([]);
      return;
    }
    const timer = setTimeout(() => {
      searchCity(searchQuery);
    }, 400);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // --- Methods ---
  const fetchWeather = async (lat: number, lon: number, cityName: string) => {
    try {
      setLoading(true);
      setError(null);
      // Clean insights when swapping locations to prevent stale advisors
      setAiInsights(null);

      const response = await fetch(`/api/weather/forecast?lat=${lat}&lon=${lon}&city=${encodeURIComponent(cityName)}`);
      if (!response.ok) {
        throw new Error("Could not retrieve weather telemetry.");
      }
      const data = await response.json();
      setWeatherData(data);

      // Save to recent searches
      setRecentSearches((prev) => {
        const filtered = prev.filter((item) => item.name.toLowerCase() !== cityName.toLowerCase());
        const updated = [{ name: cityName, lat, lon }, ...filtered];
        return updated.slice(0, 5); // Limit to 5
      });
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to establish cloud telemetry link.");
    } finally {
      setLoading(false);
    }
  };

  const fetchNews = async () => {
    try {
      setNewsLoading(true);
      const res = await fetch("/api/weather/news");
      if (res.ok) {
        const data = await res.json();
        setNews(data.news);
      }
    } catch (err) {
      console.error("News fetch error:", err);
    } finally {
      setNewsLoading(false);
    }
  };

  const searchCity = async (query: string) => {
    try {
      const res = await fetch(`/api/weather/search?q=${encodeURIComponent(query)}`);
      if (res.ok) {
        const data = await res.json();
        setSearchResults(data.results || []);
        setShowDropdown(true);
      }
    } catch (err) {
      console.error("Autocomplete failed:", err);
    }
  };

  const generateAiInsights = async () => {
    if (!weatherData) return;
    try {
      setInsightsLoading(true);
      setError(null);

      const res = await fetch("/api/weather/ai-insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ weatherData }),
      });

      if (!res.ok) {
        throw new Error("Gemini weather cognitive core declined your key or timed out.");
      }

      const data = await res.json();
      setAiInsights(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Cognitive logic pipeline stalled. Check GEMINI_API_KEY.");
    } finally {
      setInsightsLoading(false);
    }
  };

  // GPS Auto-detector
  const detectLocation = () => {
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your current browser build.");
      return;
    }
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = parseFloat(pos.coords.latitude.toFixed(4));
        const lon = parseFloat(pos.coords.longitude.toFixed(4));
        
        // Reverse geocode GPS
        let resolvedCityName = `GPS Location: ${lat}, ${lon}`;
        try {
          const revUrl = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json&accept-language=en`;
          const res = await fetch(revUrl, {
            headers: { "User-Agent": "aistudio-weather-platform" },
          });
          if (res.ok) {
            const payload = await res.json();
            resolvedCityName = payload.address?.city || payload.address?.town || payload.address?.village || payload.display_name?.split(",")[0] || resolvedCityName;
          }
        } catch (err) {
          console.warn("Reverse GPS geocoding failed.");
        }

        setCurrentCity({ name: resolvedCityName, lat, lon });
      },
      (err) => {
        console.error(err);
        setError("GPS sensor access denied. Please choose manually or adjust frame permissions.");
        setLoading(false);
      }
    );
  };

  // Voice Speech dictator
  const startVoiceSearch = () => {
    if (!SpeechRecognition) {
      setError("Speech recognition is not fully supported in this environment/browser.");
      return;
    }
    const rec = new SpeechRecognition();
    rec.lang = "en-US";
    rec.interimResults = false;
    rec.maxAlternatives = 1;

    rec.onstart = () => setVoiceActive(true);
    rec.onend = () => setVoiceActive(false);
    rec.onerror = () => {
      setError("Voice synthesis error. Try checking mic clearance.");
      setVoiceActive(false);
    };

    rec.onresult = (event: any) => {
      const speechToText = event.results[0][0].transcript;
      setSearchQuery(speechToText);
      searchCity(speechToText);
    };

    rec.start();
  };

  // Favorite toggle helper
  const isFavorite = favorites.some((f) => f.name.toLowerCase() === currentCity.name.toLowerCase());
  const toggleFavorite = () => {
    if (isFavorite) {
      setFavorites((prev) => prev.filter((f) => f.name.toLowerCase() !== currentCity.name.toLowerCase()));
    } else {
      setFavorites((prev) => [
        ...prev,
        { name: currentCity.name, lat: currentCity.lat, lon: currentCity.lon, country: "Custom" },
      ]);
    }
  };

  // Formatting helpers
  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case "Sun": return <Sun className="w-12 h-12 text-amber-400" />;
      case "SunDim": return <SunDim className="w-12 h-12 text-amber-300" />;
      case "CloudSun": return <CloudSun className="w-12 h-12 text-sky-300" />;
      case "Cloud": return <Cloud className="w-12 h-12 text-slate-300" />;
      case "CloudFog": return <CloudFog className="w-12 h-12 text-zinc-300" />;
      case "CloudDrizzle": return <CloudDrizzle className="w-12 h-12 text-blue-300" />;
      case "CloudRain": return <CloudRain className="w-12 h-12 text-blue-400" />;
      case "CloudRainWind": return <CloudRainWind className="w-12 h-12 text-indigo-400" />;
      case "CloudSnow": return <CloudSnow className="w-12 h-12 text-cyan-300" />;
      case "Snowflake": return <Snowflake className="w-12 h-12 text-cyan-200" />;
      case "CloudLightning": return <CloudLightning className="w-12 h-12 text-purple-400 animate-pulse" />;
      default: return <Sun className="w-12 h-12 text-amber-400" />;
    }
  };

  const formatTemp = (celsius: number) => {
    if (settings.units === "imperial") {
      return `${Math.round((celsius * 9) / 5 + 32)}°F`;
    }
    return `${Math.round(celsius)}°C`;
  };

  const getAqiDescription = (us_aqi: number) => {
    if (us_aqi <= 50) return { label: "Excellent", color: "text-emerald-400 border-emerald-500/20 bg-emerald-500/10" };
    if (us_aqi <= 100) return { label: "Moderate", color: "text-yellow-400 border-yellow-500/20 bg-yellow-500/10" };
    if (us_aqi <= 150) return { label: "Unhealthy for Sensitive", color: "text-orange-400 border-orange-500/20 bg-orange-500/10" };
    return { label: "Critical", color: "text-red-400 border-red-500/20 bg-red-500/10" };
  };

  const currentWCode = weatherData?.forecast?.current?.weather_code ?? 0;
  const currentDetails = WEATHER_CODE_MAP[currentWCode] || { label: "Atmosphere", icon: "Sun", bg: "from-amber-500/20 to-orange-500/5" };

  return (
    <div className={`min-h-screen text-slate-100 flex flex-col font-sans transition-all duration-500 select-none ${
      settings.theme === "matrix-green" ? "bg-black" : settings.theme === "neon-cyber" ? "bg-[#06020c]" : "bg-[#050505] bg-dots"
    } ${settings.accessibility ? "text-lg tracking-wide select-text border-[3px] border-slate-700" : ""}`}>
      
      {/* Adaptable cyber particles */}
      <BackgroundParticles weatherCode={currentWCode} theme={settings.theme} />

      {/* Primary Container Layer */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 md:px-6 py-6 flex flex-col gap-8 flex-1">
        
        {/* HEADER SECTION */}
        <header className="flex flex-col gap-4 lg:flex-row lg:items-center justify-between glass rounded-2xl p-4 lg:px-6 lg:py-4 shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 shadow-[0_0_15px_rgba(34,211,238,0.2)]">
                <Globe className="w-6 h-6 text-cyan-400 animate-spin" style={{ animationDuration: "12s" }} />
              </div>
              <div>
                <h1 className="text-xl font-display font-bold text-slate-100 uppercase tracking-tight flex items-center gap-2">
                  Aura<span className="text-cyan-400">Meteorology</span>
                  <span className="text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-mono px-2 py-0.5 rounded-full uppercase tracking-normal">
                    v2.0 PRO
                  </span>
                </h1>
                <p className="text-[10px] text-white/40 font-mono tracking-wider">ENTERPRISE CLIMATE INTELLIGENCE PLATFORM</p>
              </div>
            </div>
            {/* Quick action buttons on mobile */}
            <div className="lg:hidden flex items-center gap-2">
              <button
                onClick={() => setShowSettingsModal(true)}
                className="p-2 bg-white/5 border border-white/10 rounded-xl hover:text-cyan-400"
              >
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Autocomplete Search input block */}
          <div ref={autocompleteRef} className="relative flex-1 max-w-xl w-full mx-auto lg:mx-0">
            <div className="relative flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                <input
                  type="text"
                  placeholder="Intercept City atmosphere data..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setShowDropdown(true)}
                  className="w-full bg-white/5 border border-white/10 focus:border-cyan-500/40 focus:ring-1 focus:ring-cyan-500/20 text-[#f8fafc] text-xs rounded-full pl-10 pr-12 py-3.5 outline-none font-mono tracking-tight transition-all placeholder:text-white/30"
                />
                
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Dictation triggers */}
              <button
                onClick={startVoiceSearch}
                className={`p-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full transition-all ${
                  voiceActive ? "text-red-400 bg-red-500/10 border-red-500/30 shadow-[0_0_15px_rgba(239,68,68,0.25)]" : "text-white/60 hover:text-white"
                }`}
                title="Voice Search Activation"
              >
                <Mic className="w-4 h-4" />
              </button>

              {/* GPS Position detector */}
              <button
                onClick={detectLocation}
                className="p-3 bg-white/5 hover:bg-white/10 border border-white/10 text-white/60 hover:text-white rounded-full transition-all"
                title="Autodetect GPS"
              >
                <Navigation className="w-4 h-4" />
              </button>
            </div>

            {/* Autocomplete lists Dropdown */}
            {showDropdown && (searchResults.length > 0 || recentSearches.length > 0) && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-black/95 border border-white/10 rounded-2xl p-3 shadow-2xl z-50 backdrop-blur-xl">
                {searchResults.length > 0 && (
                  <div className="mb-3">
                    <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest px-2.5">Global Search Results</span>
                    <div className="flex flex-col gap-1 mt-1.5">
                      {searchResults.map((city) => (
                        <button
                          key={city.id || `${city.latitude}_${city.longitude}`}
                          onClick={() => {
                            setCurrentCity({ name: city.name, lat: city.latitude, lon: city.longitude });
                            setSearchQuery("");
                            setShowDropdown(false);
                          }}
                          className="flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-white/5 text-left text-xs text-white/70 transition-all font-sans"
                        >
                          <span className="font-medium text-white">{city.name}</span>
                          <span className="text-[10px] font-mono text-white/30">
                            {city.admin1 ? `${city.admin1}, ` : ""}{city.country} ({city.latitude.toFixed(1)}, {city.longitude.toFixed(1)})
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {recentSearches.length > 0 && (
                  <div>
                    <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest px-2.5">Recent Interceptions</span>
                    <div className="flex flex-col gap-1 mt-1.5">
                      {recentSearches.map((city, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            setCurrentCity({ name: city.name, lat: city.lat, lon: city.lon });
                            setShowDropdown(false);
                          }}
                          className="flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-white/5 text-left text-xs text-white/70 transition-all font-sans"
                        >
                          <span className="text-white/80 font-medium">{city.name}</span>
                          <span className="text-[10px] font-mono text-white/30">
                            {city.lat.toFixed(2)}, {city.lon.toFixed(2)}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Settings / quick switch rail on large screens */}
          <div className="hidden lg:flex items-center gap-3">
            <button
              onClick={() => setSettings(prev => ({ ...prev, units: prev.units === "metric" ? "imperial" : "metric" }))}
              className="px-4 py-2.5 bg-white/5 border border-white/10 rounded-full text-[10px] font-mono text-white/80 hover:text-cyan-400 tracking-tight transition-all"
            >
              UNIT: {settings.units.toUpperCase()}
            </button>
            <button
              onClick={() => setShowSettingsModal(true)}
              className="p-3 bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 hover:text-cyan-400 rounded-full transition-all"
              title="Full system settings"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Global Error Banner */}
        {error && (
          <div className="p-4 bg-red-950/20 border border-red-500/20 rounded-2xl flex items-center justify-between shadow-[0_0_15px_rgba(239,68,68,0.05)]">
            <div className="flex items-center gap-3">
              <ShieldAlert className="w-5 h-5 text-red-400 shrink-0" />
              <div className="text-xs">
                <span className="font-bold font-mono text-red-400 uppercase mr-1">Telemetry Stall:</span>
                <span className="text-slate-300 leading-relaxed font-sans">{error}</span>
              </div>
            </div>
            <button onClick={() => setError(null)} className="text-slate-500 hover:text-slate-300">
              <X className="w-4.5 h-4.5" />
            </button>
          </div>
        )}

        {/* FAVORITES PRESET BAR */}
        <div id="favorites-bar" className="flex flex-wrap items-center gap-2 glass p-2.5 rounded-2xl overflow-x-auto">
          <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest mr-2 flex items-center gap-1">
            <Heart className="w-3 h-3 text-rose-500" /> SAVED SECTORS:
          </span>
          {favorites.map((city, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentCity({ name: city.name, lat: city.lat, lon: city.lon })}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono tracking-tight transition-all flex items-center gap-1.5 ${
                currentCity.name.toLowerCase() === city.name.toLowerCase()
                  ? "bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-medium"
                  : "bg-white/5 border border-transparent hover:border-white/10 text-white/60 hover:text-white"
              }`}
            >
              {city.name}
              {city.country && city.country !== "Custom" && (
                <span className="text-[8px] text-white/30">{city.country.slice(0, 3).toUpperCase()}</span>
              )}
            </button>
          ))}
        </div>

        {/* LOADING CORE OVERLAY */}
        {loading ? (
          <div className="flex-1 flex flex-col items-center justify-center py-24 gap-4">
            <div className="relative flex items-center justify-center">
              <div className="absolute w-16 h-16 rounded-full border border-cyan-500/20 animate-ping" />
              <div className="w-10 h-10 rounded-full border-4 border-white/5 border-t-cyan-400 animate-spin" />
            </div>
            <div className="text-center">
              <h3 className="text-sm font-mono text-slate-300 tracking-widest animate-pulse">DOWNLINKING CLIMATE CHANNELS...</h3>
              <p className="text-[10px] text-white/40 font-mono mt-1 uppercase">ESTABLISHING QUANTUM COGNITIVE VECTORS</p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-8">

            {/* HERO / CURRENT ATMOSPHERIC CONTEXT */}
            <section id="hero-current-weather" className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
              
              {/* Main Weather Card (Floating visual) */}
              <div className="lg:col-span-2 glass rounded-3xl p-6 relative overflow-hidden shadow-2xl flex flex-col justify-between h-full min-h-[300px]">
                
                {/* Visual elements */}
                <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-cyan-500/10 blur-[80px] pointer-events-none" />

                <div className="flex items-start justify-between relative z-10">
                  <div>
                    <h2 className="text-2xl font-display font-semibold text-white tracking-tight flex items-center gap-2">
                      {weatherData?.cityName}
                      <button
                        onClick={toggleFavorite}
                        className="p-1.5 hover:bg-white/5 rounded-lg text-rose-500 transition-all"
                        title={isFavorite ? "Remove from Saved Sectors" : "Save to Favorites"}
                      >
                        <Heart className="w-5 h-5" fill={isFavorite ? "#f43f5e" : "transparent"} />
                      </button>
                    </h2>
                    <p className="text-xs text-white/40 font-mono mt-1 uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                      DATA REFRESH OK • {new Date(weatherData?.fetchedAt ?? Date.now()).toLocaleTimeString()}
                    </p>
                  </div>
                  
                  {/* Big Custom Weather Icon */}
                  <div className="p-3 bg-white/5 border border-white/10 rounded-2xl shadow-xl">
                    {getIconComponent(currentDetails.icon)}
                  </div>
                </div>

                {/* Mid: Giant Temperature Readout */}
                <div className="my-6 flex items-baseline gap-4 relative z-10">
                  <h3 className="text-6xl md:text-7xl font-mono font-semibold text-transparent bg-clip-text bg-gradient-to-r from-white to-white/60 tracking-tighter">
                    {weatherData && formatTemp(weatherData.forecast.current.temperature_2m)}
                  </h3>
                  <div>
                    <div className="text-xs font-mono text-white/40 uppercase tracking-widest">FEELS LIKE</div>
                    <div className="text-lg font-sans font-medium text-white/80">
                      {weatherData && formatTemp(weatherData.forecast.current.apparent_temperature)}
                    </div>
                  </div>
                </div>

                {/* Bottom descriptor row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-t border-white/5 pt-4 relative z-10 gap-3">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xs text-white/40 font-mono">STATUS COMPILATION:</span>
                    <span className="text-xs font-mono font-semibold uppercase text-cyan-400 tracking-wider">
                      {currentDetails.label}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-4 text-xs font-mono text-white/55">
                    <div>LAT: {weatherData?.latitude}°</div>
                    <div>LON: {weatherData?.longitude}°</div>
                  </div>
                </div>
              </div>

              {/* Advanced Air Quality and UV Index cyber cards (Right side on large screens) */}
              <div className="glass rounded-3xl p-6 shadow-2xl flex flex-col justify-between gap-6 h-full">
                {/* Air Quality Index Card */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xs font-mono text-white/40 uppercase tracking-widest">AIR QUALITY PROFILE</h3>
                    {weatherData?.airQuality && (
                      <span className={`text-[10px] font-mono uppercase font-bold tracking-widest px-2.5 py-0.5 border rounded-full ${
                        getAqiDescription(weatherData.airQuality.current.us_aqi).color
                      }`}>
                        {getAqiDescription(weatherData.airQuality.current.us_aqi).label}
                      </span>
                    )}
                  </div>

                  <div className="flex items-baseline gap-2.5">
                    <span className="text-4xl font-mono font-bold text-white">
                      {weatherData?.airQuality?.current?.us_aqi ?? "N/A"}
                    </span>
                    <span className="text-xs font-mono text-white/40">US AQI</span>
                  </div>

                  {/* Micro metric meters */}
                  <div className="grid grid-cols-2 gap-4 mt-4 text-[11px] font-sans">
                    <div className="flex flex-col gap-1.5 p-2 bg-white/5 border border-white/10 rounded-xl">
                      <span className="text-white/40 font-mono text-[9px] uppercase">PM2.5</span>
                      <span className="text-white/80 font-mono font-medium">
                        {weatherData?.airQuality?.current?.pm2_5 ?? "N/A"} µg/m³
                      </span>
                    </div>
                    <div className="flex flex-col gap-1.5 p-2 bg-white/5 border border-white/10 rounded-xl">
                      <span className="text-white/40 font-mono text-[9px] uppercase">PM10</span>
                      <span className="text-white/80 font-mono font-medium">
                        {weatherData?.airQuality?.current?.pm10 ?? "N/A"} µg/m³
                      </span>
                    </div>
                  </div>
                </div>

                {/* UV Index metrics */}
                <div className="border-t border-white/5 pt-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xs font-mono text-white/40 uppercase tracking-widest">UV SUNBURST RADIATION</h3>
                    <span className="text-xs font-mono text-cyan-400 font-semibold">
                      PEAK: {weatherData?.forecast?.daily?.uv_index_max?.[0] ?? "N/A"}
                    </span>
                  </div>
                  <div className="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-cyan-400 to-teal-400 h-1.5 rounded-full"
                      style={{ width: `${Math.min(100, ((weatherData?.forecast?.daily?.uv_index_max?.[0] ?? 0) / 12) * 100)}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-white/40 leading-normal mt-2 leading-relaxed">
                    Solar ultraviolet emissions scale is currently categorized as{" "}
                    <span className="text-white/60">
                      {(weatherData?.forecast?.daily?.uv_index_max?.[0] ?? 0) >= 6 ? "High risk" : "Mild exposure"}
                    </span>
                    . Adapt protections.
                  </p>
                </div>
              </div>
            </section>

            {/* SECONDARY ATMOSPHERIC CORE PARAMETERS */}
            <section id="secondary-indicators" className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {[
                { label: "Humidity", icon: <Droplets className="w-5 h-5 text-cyan-400" />, val: `${weatherData?.forecast?.current?.relative_humidity_2m}%`, desc: "Intraday moisture" },
                { label: "Wind speed", icon: <Wind className="w-5 h-5 text-cyan-400" />, val: `${weatherData?.forecast?.current?.wind_speed_10m} km/h`, desc: `Direction: ${weatherData?.forecast?.current?.wind_direction_10m}°` },
                { label: "Pressure", icon: <Gauge className="w-5 h-5 text-cyan-400" />, val: `${weatherData?.forecast?.current?.pressure_msl} hPa`, desc: "Barometric metrics" },
                { label: "Visibility", icon: <Eye className="w-5 h-5 text-cyan-400" />, val: `${weatherData?.forecast?.hourly?.visibility?.[0] ? Math.round(weatherData.forecast.hourly.visibility[0] / 1000) : "N/A"} km`, desc: "Optical clarity" },
                { label: "Dew point", icon: <Thermometer className="w-5 h-5 text-cyan-400" />, val: `${weatherData?.forecast?.hourly?.dew_point_2m?.[0] ? formatTemp(weatherData.forecast.hourly.dew_point_2m[0]) : "N/A"}`, desc: "Condensation threshold" },
                { label: "Sunrise/Sunset", icon: <Sunrise className="w-5 h-5 text-cyan-400" />, val: `${weatherData?.forecast?.daily?.sunrise?.[0] ? new Date(weatherData.forecast.daily.sunrise[0]).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "N/A"}`, desc: `Sunset: ${weatherData?.forecast?.daily?.sunset?.[0] ? new Date(weatherData.forecast.daily.sunset[0]).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "N/A"}` },
              ].map((ind, idx) => (
                <div key={idx} className="glass rounded-2xl p-4 flex flex-col justify-between shadow-md relative overflow-hidden group hover:border-cyan-500/30 transition-all">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-mono text-white/40 uppercase tracking-tight">{ind.label}</span>
                    <div className="p-1.5 bg-white/5 border border-white/10 rounded-lg group-hover:scale-105 transition-all">
                      {ind.icon}
                    </div>
                  </div>
                  <div>
                    <div className="text-lg font-sans font-semibold text-white/90">{ind.val}</div>
                    <div className="text-[9px] font-mono text-white/30 mt-1 uppercase">{ind.desc}</div>
                  </div>
                </div>
              ))}
            </section>

            {/* CHART TELEMETRY VIEW */}
            {weatherData && (
              <WeatherCharts hourly={weatherData.forecast.hourly} settings={settings} />
            )}

            {/* HORIZONTAL 14-DAY FORECAST SLIDER */}
            <section id="fortnight-forecast" className="glass rounded-3xl p-6 shadow-2xl overflow-hidden relative">
              <div className="mb-4">
                <h2 className="text-xl font-sans font-medium text-slate-100 tracking-tight flex items-center gap-2">
                  <CalendarDays className="w-5 h-5 text-cyan-400" />
                  Atmospheric Fortnight Outlook (14-Day Forecast)
                </h2>
                <p className="text-xs text-white/40 font-mono mt-0.5">EXTENDED DIURNAL VECTOR MODELS</p>
              </div>

              <div className="flex gap-4 overflow-x-auto pb-4 custom-scrollbar">
                {weatherData?.forecast?.daily?.time.map((time, idx) => {
                  const maxTemp = weatherData.forecast.daily.temperature_2m_max[idx];
                  const minTemp = weatherData.forecast.daily.temperature_2m_min[idx];
                  const code = weatherData.forecast.daily.weather_code[idx];
                  const rainRisk = weatherData.forecast.daily.precipitation_probability_max[idx];
                  const details = WEATHER_CODE_MAP[code] || { label: "Atmosphere", icon: "Sun" };

                  const d = new Date(time);
                  const dayName = d.toLocaleDateString([], { weekday: "short" });
                  const dateLabel = d.toLocaleDateString([], { month: "short", day: "numeric" });

                  return (
                    <div
                      key={idx}
                      className="min-w-[125px] flex-1 glass hover:bg-white/5 rounded-2xl p-4 flex flex-col items-center justify-between text-center transition-all shadow-md shrink-0 relative overflow-hidden"
                    >
                      {/* Highlight first column */}
                      {idx === 0 && (
                        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-cyan-400 to-teal-400" />
                      )}

                      <div className="mb-2">
                        <div className="text-xs font-sans font-semibold text-white/80 uppercase tracking-wider">{idx === 0 ? "Today" : dayName}</div>
                        <div className="text-[10px] font-mono text-white/30 mt-0.5">{dateLabel}</div>
                      </div>

                      <div className="my-3 p-2 bg-white/5 border border-white/10 rounded-xl shadow-inner">
                        {getIconComponent(details.icon)}
                      </div>

                      <div className="flex flex-col gap-1">
                        <div className="text-xs font-mono font-bold text-white">
                          {formatTemp(maxTemp)}
                        </div>
                        <div className="text-[10px] font-mono text-white/40">
                          {formatTemp(minTemp)}
                        </div>
                      </div>

                      <div className="mt-3 pt-2.5 border-t border-white/5 w-full flex flex-col gap-1">
                        <span className="text-[9px] font-mono text-white/50 uppercase truncate px-1 block max-w-full">
                          {details.label}
                        </span>
                        <span className="text-[9px] font-mono text-cyan-400 flex items-center justify-center gap-1">
                          ☔ {rainRisk}%
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* DUAL COLUMN METRIC VIEW: Interactive Map & newsalert / cyclone tracking */}
            <section className="grid grid-cols-1 xl:grid-cols-5 gap-6 items-stretch">
              
              {/* Interactive World Map column (3/5 width) */}
              <div className="xl:col-span-3">
                <WeatherMap
                  lat={currentCity.lat}
                  lon={currentCity.lon}
                  cityName={currentCity.name}
                  onCoordinatesSelected={(lat, lon, name) => setCurrentCity({ name, lat, lon })}
                  settings={settings}
                />
              </div>

              {/* Climate Alert news beacon column (2/5 width) */}
              <div className="xl:col-span-2">
                <NewsFeed news={news} loading={newsLoading} />
              </div>
            </section>

            {/* COGNITIVE AI INTEGRATION PANEL */}
            <section className="mt-4">
              <AiAdvisor
                weatherData={weatherData}
                insights={aiInsights}
                onGenerateInsights={generateAiInsights}
                loading={insightsLoading}
              />
            </section>

          </div>
        )}

      </div>

      {/* MODAL CONFIGURATOR PANEL (Theme, unit, accessibility configs) */}
      <AnimatePresence>
        {showSettingsModal && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#050505] border border-white/10 rounded-3xl p-6 w-full max-w-md shadow-2xl relative bg-dots"
            >
              <button
                onClick={() => setShowSettingsModal(false)}
                className="absolute right-4 top-4 text-white/40 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="mb-6">
                <h3 className="text-lg font-display font-semibold text-white flex items-center gap-2">
                  <Settings className="w-5 h-5 text-cyan-400" />
                  Lab Command Center
                </h3>
                <p className="text-xs text-white/40 font-mono mt-0.5">CONFIGURE INTERFACE & UNIT TELEMETRIES</p>
              </div>

              <div className="flex flex-col gap-5">
                {/* 1. Temperature units */}
                <div className="flex flex-col gap-2">
                  <span className="text-xs font-mono text-white/40 uppercase tracking-wider">Atmospheric Scale</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setSettings((prev) => ({ ...prev, units: "metric" }))}
                      className={`py-2 rounded-xl text-xs font-mono tracking-tight border transition-all ${
                        settings.units === "metric"
                          ? "bg-cyan-500/10 border-cyan-500/40 text-cyan-400"
                          : "bg-white/5 border-transparent text-white/50 hover:text-white"
                      }`}
                    >
                      METRIC (°C, km/h)
                    </button>
                    <button
                      onClick={() => setSettings((prev) => ({ ...prev, units: "imperial" }))}
                      className={`py-2 rounded-xl text-xs font-mono tracking-tight border transition-all ${
                        settings.units === "imperial"
                          ? "bg-cyan-500/10 border-cyan-500/40 text-cyan-400"
                          : "bg-white/5 border-transparent text-white/50 hover:text-white"
                      }`}
                    >
                      IMPERIAL (°F, mph)
                    </button>
                  </div>
                </div>

                {/* 2. Visual Theme switchers */}
                <div className="flex flex-col gap-2">
                  <span className="text-xs font-mono text-white/40 uppercase tracking-wider">Visual Deck Profile</span>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: "quantum-slate", label: "QUANTUM SLATE", border: "hover:border-cyan-500/35" },
                      { id: "neon-cyber", label: "NEON CYBER", border: "hover:border-rose-500/35" },
                      { id: "matrix-green", label: "MATRIX GREEN", border: "hover:border-emerald-500/35" },
                    ].map((th) => (
                      <button
                        key={th.id}
                        onClick={() => setSettings((prev) => ({ ...prev, theme: th.id as any }))}
                        className={`py-3 rounded-xl text-[10px] font-mono tracking-tighter border flex flex-col items-center justify-center gap-1 transition-all ${
                          settings.theme === th.id
                            ? "bg-white/10 border-white/20 text-white"
                            : "bg-white/5 border-transparent text-white/40 " + th.border
                        }`}
                      >
                        <span className={`w-3 h-3 rounded-full ${
                          th.id === "neon-cyber" ? "bg-rose-500" : th.id === "matrix-green" ? "bg-emerald-500" : "bg-cyan-400"
                        }`} />
                        {th.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 3. Language settings */}
                <div className="flex flex-col gap-2">
                  <span className="text-xs font-mono text-white/40 uppercase tracking-wider flex items-center gap-1.5">
                    <Languages className="w-4 h-4 text-cyan-400" />
                    Core Deck Language
                  </span>
                  <select
                    value={settings.language}
                    onChange={(e) => setSettings((prev) => ({ ...prev, language: e.target.value as any }))}
                    className="bg-white/5 border border-white/10 text-white/80 text-xs rounded-xl p-3 outline-none font-mono tracking-tight"
                  >
                    <option value="en" className="bg-[#050505] text-white">ENGLISH (US / UK)</option>
                    <option value="es" className="bg-[#050505] text-white">ESPAÑOL (ES)</option>
                    <option value="fr" className="bg-[#050505] text-white">FRANÇAIS (FR)</option>
                    <option value="jp" className="bg-[#050505] text-white">日本語 (JP)</option>
                  </select>
                </div>

                {/* 4. Accessibility toggling */}
                <div className="flex flex-col gap-2">
                  <span className="text-xs font-mono text-white/40 uppercase tracking-wider flex items-center gap-1.5">
                    <Accessibility className="w-4 h-4 text-cyan-400" />
                    Accessibility Mode
                  </span>
                  <button
                    onClick={() => setSettings((prev) => ({ ...prev, accessibility: !prev.accessibility }))}
                    className={`py-3 rounded-xl text-xs font-mono tracking-tight border flex items-center justify-between px-4 transition-all ${
                      settings.accessibility
                        ? "bg-cyan-500/10 border-cyan-500/40 text-cyan-400 font-bold"
                        : "bg-white/5 border-transparent text-white/50"
                    }`}
                  >
                    <span>CYBER CONTRAST & ENHANCED COPY</span>
                    <span className="text-[10px] uppercase font-bold">
                      {settings.accessibility ? "ENABLED" : "DISABLED"}
                    </span>
                  </button>
                </div>
              </div>

              <div className="mt-8 pt-4 border-t border-white/5 flex items-center justify-end">
                <button
                  onClick={() => setShowSettingsModal(false)}
                  className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 active:scale-[0.98] text-xs font-mono font-semibold tracking-tight text-black rounded-xl transition-all"
                >
                  SAVE DECK PRESETS
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* FOOTER AREA */}
      <footer className="mt-auto border-t border-white/5 py-6 text-center text-xs text-white/40 font-mono tracking-wider flex flex-col sm:flex-row items-center justify-between max-w-7xl w-full mx-auto px-4 md:px-6 relative z-10 gap-2">
        <span>AURA METEOROLOGY LABORATORIES • COPYRIGHT 2026</span>
        <span className="flex items-center gap-1.5 uppercase text-[10px] text-white/40">
          <Activity className="w-3.5 h-3.5 text-cyan-400" />
          DECISION TELEMETRY STREAM SECURE (SSL-256)
        </span>
      </footer>

    </div>
  );
}
