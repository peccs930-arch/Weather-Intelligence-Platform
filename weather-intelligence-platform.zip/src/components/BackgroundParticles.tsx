import React, { useEffect, useState, useRef } from "react";

interface ParticlesProps {
  weatherCode: number;
  theme: string;
}

export default function BackgroundParticles({ weatherCode, theme }: ParticlesProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (canvas) {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
      }
    };

    window.addEventListener("resize", handleResize);

    // Particles setup based on weather code
    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      alpha: number;
      color: string;
    }> = [];

    const getParticleConfig = () => {
      // Thunderstorms / heavy rain
      if (weatherCode >= 80 || weatherCode >= 95 || (weatherCode >= 60 && weatherCode <= 65)) {
        return {
          count: 80,
          color: theme === "neon-cyber" ? "rgba(0, 242, 254, 0.4)" : "rgba(34, 211, 238, 0.4)",
          minVy: 8,
          maxVy: 14,
          minVx: -2,
          maxVx: 0,
          radius: 1,
          type: "rain",
        };
      }
      // Drizzle / slight rain
      if (weatherCode >= 51 && weatherCode <= 57) {
        return {
          count: 40,
          color: "rgba(186, 230, 253, 0.3)",
          minVy: 4,
          maxVy: 7,
          minVx: -1,
          maxVx: 0,
          radius: 0.8,
          type: "drizzle",
        };
      }
      // Snow
      if ((weatherCode >= 71 && weatherCode <= 77) || weatherCode === 85 || weatherCode === 86) {
        return {
          count: 50,
          color: "rgba(255, 255, 255, 0.6)",
          minVy: 1,
          maxVy: 3,
          minVx: -1,
          maxVx: 1,
          radius: 2,
          type: "snow",
        };
      }
      // Clear or Partly Cloudy - cyber dust / solar sparkles
      return {
        count: 35,
        color:
          theme === "matrix-green"
            ? "rgba(34, 197, 94, 0.25)"
            : theme === "neon-cyber"
            ? "rgba(244, 63, 94, 0.2)"
            : "rgba(34, 211, 238, 0.3)", // Cyber cyan dust
        minVy: -0.5,
        maxVy: 0.5,
        minVx: -0.5,
        maxVx: 0.5,
        radius: 1.5,
        type: "dust",
      };
    };

    const config = getParticleConfig();

    for (let i = 0; i < config.count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: Math.random() * (config.maxVx - config.minVx) + config.minVx,
        vy: Math.random() * (config.maxVy - config.minVy) + config.minVy,
        radius: Math.random() * config.radius + 0.5,
        alpha: Math.random() * 0.5 + 0.2,
        color: config.color,
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      // Light gradient overlay depending on theme
      const grad = ctx.createRadialGradient(width / 2, height / 2, 10, width / 2, height / 2, width);
      if (theme === "matrix-green") {
        grad.addColorStop(0, "rgba(5, 22, 10, 0.4)");
        grad.addColorStop(1, "rgba(2, 8, 4, 0.95)");
      } else if (theme === "neon-cyber") {
        grad.addColorStop(0, "rgba(20, 10, 30, 0.4)");
        grad.addColorStop(1, "rgba(6, 2, 12, 0.95)");
      } else {
        // Quantum Slate (Sophisticated Dark)
        grad.addColorStop(0, "rgba(5, 5, 5, 0.4)");
        grad.addColorStop(1, "rgba(5, 5, 5, 0.98)");
      }
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      particles.forEach((p) => {
        ctx.beginPath();
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;

        if (config.type === "rain" || config.type === "drizzle") {
          // Draw streak instead of circle
          ctx.strokeStyle = p.color;
          ctx.lineWidth = p.radius;
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + p.vx * 2, p.y + p.vy * 2);
          ctx.stroke();
        } else {
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();

        // Update positions
        p.x += p.vx;
        p.y += p.vy;

        // Recycle particles
        if (config.type === "rain" || config.type === "drizzle" || config.type === "snow") {
          if (p.y > height) {
            p.y = -10;
            p.x = Math.random() * width;
          }
          if (p.x < 0 || p.x > width) {
            p.x = Math.random() * width;
          }
        } else {
          // Float bounce
          if (p.x < 0 || p.x > width) p.vx *= -1;
          if (p.y < 0 || p.y > height) p.vy *= -1;
        }
      });

      animationId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", handleResize);
    };
  }, [weatherCode, theme]);

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" />;
}
