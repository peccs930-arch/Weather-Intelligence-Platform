import React from "react";
import { WeatherNewsItem } from "../types";
import { AlertTriangle, ShieldAlert, Waves, Shield, Flame, Activity } from "lucide-react";
import { motion } from "motion/react";

interface NewsFeedProps {
  news: WeatherNewsItem[];
  loading: boolean;
}

export default function NewsFeed({ news, loading }: NewsFeedProps) {
  const getSeverityStyles = (severity: WeatherNewsItem["severity"]) => {
    switch (severity) {
      case "critical":
        return {
          badge: "bg-red-500/20 text-red-400 border-red-500/30",
          glow: "shadow-[0_0_15px_rgba(239,68,68,0.15)]",
          icon: <ShieldAlert className="w-5 h-5 text-red-400 animate-bounce" />,
        };
      case "high":
        return {
          badge: "bg-amber-500/20 text-amber-400 border-amber-500/30",
          glow: "shadow-[0_0_15px_rgba(245,158,11,0.1)]",
          icon: <AlertTriangle className="w-5 h-5 text-amber-400" />,
        };
      case "medium":
        return {
          badge: "bg-sky-500/20 text-sky-400 border-sky-500/30",
          glow: "",
          icon: <Waves className="w-5 h-5 text-sky-400" />,
        };
      default:
        return {
          badge: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
          glow: "",
          icon: <Shield className="w-5 h-5 text-emerald-400" />,
        };
    }
  };

  return (
    <div id="weather-news-feed" className="glass rounded-3xl p-6 shadow-2xl relative overflow-hidden flex flex-col h-full">
      <div className="mb-6">
        <h2 className="text-xl font-sans font-medium text-white tracking-tight flex items-center gap-2">
          <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
          Seismic & Severe Climate Intelligence Feed
        </h2>
        <p className="text-xs text-white/40 font-mono mt-0.5">GLOBAL DISASTER & WEATHER HAZARD ALERT BEACON</p>
      </div>

      {loading ? (
        <div className="flex-1 flex flex-col items-center justify-center py-12 gap-3">
          <div className="w-8 h-8 rounded-full border-4 border-white/10 border-t-cyan-400 animate-spin" />
          <span className="text-xs font-mono text-white/30">DECRYPTING SATELLITE HAZARD BEACONS...</span>
        </div>
      ) : (
        <div className="flex-1 flex flex-col gap-4 overflow-y-auto max-h-[420px] pr-2 custom-scrollbar">
          {news.map((item, idx) => {
            const styles = getSeverityStyles(item.severity);
            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: idx * 0.08 }}
                className={`p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl flex gap-4 items-start transition-all relative overflow-hidden ${styles.glow}`}
              >
                {/* Visual alert category background trace */}
                <div className="absolute right-2 -bottom-2 opacity-[0.03] text-white font-bold text-5xl font-mono uppercase tracking-widest pointer-events-none">
                  {item.category.split(" ")[0]}
                </div>

                <div className="p-2 rounded-xl bg-white/5 border border-white/10 shrink-0">
                  {styles.icon}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <span className={`text-[9px] font-mono font-bold uppercase tracking-widest px-2.5 py-0.5 border rounded-full ${styles.badge}`}>
                      {item.severity}
                    </span>
                    <span className="text-[10px] font-mono text-white/30">{item.time}</span>
                    <span className="text-[10px] font-mono text-white/30">•</span>
                    <span className="text-[10px] font-mono text-cyan-400">{item.source}</span>
                  </div>

                  <h3 className="text-sm font-sans font-medium text-white leading-snug tracking-tight mb-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-white/60 leading-relaxed font-sans">
                    {item.summary}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between text-xs font-mono text-white/40">
        <span className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
          ANTENNA ENCRYPTED SAT-FEED ONLINE
        </span>
        <span>VER 4.29G-hz</span>
      </div>
    </div>
  );
}
