import React, { useEffect, useRef } from "react";
import L from "leaflet";
import { UserSettings } from "../types";
import { MapPin, Info } from "lucide-react";

interface WeatherMapProps {
  lat: number;
  lon: number;
  cityName: string;
  onCoordinatesSelected: (lat: number, lon: number, cityName: string) => void;
  settings: UserSettings;
}

export default function WeatherMap({ lat, lon, cityName, onCoordinatesSelected, settings }: WeatherMapProps) {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerInstanceRef = useRef<L.Marker | null>(null);

  // 1. Inject Leaflet Stylesheet dynamically
  useEffect(() => {
    const linkId = "leaflet-css";
    if (!document.getElementById(linkId)) {
      const link = document.createElement("link");
      link.id = linkId;
      link.rel = "stylesheet";
      link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
      document.head.appendChild(link);
    }
  }, []);

  // 2. Initialize Map Instance
  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Destroy existing instance if there is one
    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }

    // Determine Map Theme style based on settings
    let tileUrl = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
    let attribution = '&copy; <a href="https://openstreetmap.org">OpenStreetMap</a>';

    // Dark Map tile layers for a beautiful cyber look
    if (settings.theme !== "light") {
      tileUrl = "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png";
      attribution = '&copy; <a href="https://carto.com/">CARTO</a>';
    }

    // Create Leaflet Map Instance
    const map = L.map(mapContainerRef.current, {
      center: [lat, lon],
      zoom: 5,
      zoomControl: true,
      attributionControl: true,
    });

    L.tileLayer(tileUrl, {
      attribution,
      maxZoom: 19,
    }).addTo(map);

    mapInstanceRef.current = map;

    // Handle Click anywhere to select location
    map.on("click", async (e: L.LeafletMouseEvent) => {
      const { lat: clickedLat, lng: clickedLng } = e.latlng;
      // Truncate decimals for clean processing
      const fixedLat = parseFloat(clickedLat.toFixed(4));
      const fixedLng = parseFloat(clickedLng.toFixed(4));

      // Attempt to reverse geocode name or set to Coordinates label
      let resolvedCityName = `Location: ${fixedLat}, ${fixedLng}`;
      try {
        const revUrl = `https://nominatim.openstreetmap.org/reverse?lat=${fixedLat}&lon=${fixedLng}&format=json&accept-language=en`;
        const res = await fetch(revUrl, {
          headers: { "User-Agent": "aistudio-weather-platform" },
        });
        if (res.ok) {
          const payload = await res.json();
          resolvedCityName = payload.address?.city || payload.address?.town || payload.address?.village || payload.address?.state || payload.display_name?.split(",")[0] || resolvedCityName;
        }
      } catch (err) {
        console.warn("Reverse geocode failed, using coordinates as name.");
      }

      onCoordinatesSelected(fixedLat, fixedLng, resolvedCityName);
    });

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [settings.theme]); // Reinitialize map tiles when theme changes

  // 3. Update marker and pan to coordinates when lat/lon changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Pan to target
    map.setView([lat, lon], map.getZoom() || 5);

    // Remove existing marker
    if (markerInstanceRef.current) {
      markerInstanceRef.current.remove();
    }

    // Add futuristic glowing marker
    const customIcon = L.divIcon({
      html: `
        <div class="relative flex items-center justify-center">
          <div class="absolute w-8 h-8 rounded-full bg-cyan-400/35 animate-ping"></div>
          <div class="absolute w-4 h-4 rounded-full bg-cyan-400 border-2 border-white shadow-lg"></div>
        </div>
      `,
      className: "custom-glowing-marker",
      iconSize: [20, 20],
      iconAnchor: [10, 10],
    });

    const marker = L.marker([lat, lon], { icon: customIcon }).addTo(map);
    marker.bindPopup(`<b style="color: #0c0a09">${cityName}</b><br><span style="color: #44403c">Lat: ${lat}, Lon: ${lon}</span>`).openPopup();
    markerInstanceRef.current = marker;
  }, [lat, lon, cityName]);

  return (
    <div id="interactive-world-map" className="glass rounded-3xl p-6 shadow-2xl relative overflow-hidden flex flex-col h-full">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div>
          <h2 className="text-xl font-sans font-medium text-white tracking-tight flex items-center gap-2">
            <MapPin className="w-5 h-5 text-cyan-400" />
            Interactive World Atmosphere Map
          </h2>
          <p className="text-xs text-white/40 font-mono mt-0.5">GEOPHYSICAL ATMOSPHERE SCANNER</p>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] font-mono text-white/40 bg-white/5 border border-white/10 px-2.5 py-1 rounded-lg">
          <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          CLICK ANYWHERE ON EARTH TO VIEW WEATHER FORECASTS
        </div>
      </div>

      {/* Leaflet map container */}
      <div className="relative flex-1 rounded-2xl overflow-hidden border border-white/10 h-[380px] min-h-[300px] z-10">
        <div ref={mapContainerRef} className="absolute inset-0 w-full h-full z-10" />
      </div>

      <div className="mt-3 flex items-center justify-between text-xs font-mono text-white/40">
        <span>GRID OVERLAYS: AIR DENSITY + TEMPERATURE</span>
        <span>SELECTED: {cityName} ({lat}, {lon})</span>
      </div>
    </div>
  );
}
