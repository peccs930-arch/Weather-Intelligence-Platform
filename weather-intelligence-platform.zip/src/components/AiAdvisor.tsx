import React, { useState } from "react";
import { AIInsights, WeatherData } from "../types";
import { Cpu, Shirt, Compass, HeartPulse, Sprout, Footprints, AlertTriangle, MessageSquareCode } from "lucide-react";
import { motion } from "motion/react";

interface AiAdvisorProps {
  weatherData: WeatherData | null;
  insights: AIInsights | null;
  onGenerateInsights: () => Promise<void>;
  loading: boolean;
}

export default function AiAdvisor({ weatherData, insights, onGenerateInsights, loading }: AiAdvisorProps) {
  const [selectedPanel, setSelectedPanel] = useState<string>("clothing");

  const cards = [
    {
      id: "clothing",
      title: "Clothing recommendations",
      query: "What should I wear today?",
      icon: <Shirt className="w-5 h-5 text-indigo-400" />,
      content: insights?.clothing,
    },
    {
      id: "travel",
      title: "Travel Assessment",
      query: "Can I travel today? Is it safe to drive?",
      icon: <Compass className="w-5 h-5 text-emerald-400" />,
      content: insights?.travel,
    },
    {
      id: "health",
      title: "Health & UV Guidance",
      query: "Are there any health risk advisories?",
      icon: <HeartPulse className="w-5 h-5 text-rose-400" />,
      content: insights?.health,
    },
    {
      id: "farming",
      title: "Agricultural Forecasting",
      query: "Farming, gardening & crops advice?",
      icon: <Sprout className="w-5 h-5 text-amber-400" />,
      content: insights?.farming,
    },
    {
      id: "outdoor",
      title: "Outdoor & Jogging Guide",
      query: "Can I go jogging? Fitness score?",
      icon: <Footprints className="w-5 h-5 text-cyan-400" />,
      content: insights?.outdoorActivities,
    },
  ];

  const activeCard = cards.find((c) => c.id === selectedPanel);

  return (
    <div id="ai-dashboard-panel" className="glass rounded-3xl p-6 shadow-2xl relative overflow-hidden flex flex-col h-full bg-dots">
      {/* Visual cyber mesh background trace */}
      <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-cyan-600/15 blur-[60px] pointer-events-none" />

      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-sans font-medium text-white tracking-tight flex items-center gap-2.5">
            <Cpu className="w-5 h-5 text-cyan-400 animate-spin" style={{ animationDuration: "3s" }} />
            Gemini climate AI Core
          </h2>
          <p className="text-xs text-white/40 font-mono mt-0.5">PREDICTIVE CLIMATE SYNTHESIZER AND SYNAPSES</p>
        </div>

        <button
          onClick={onGenerateInsights}
          disabled={loading || !weatherData}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-mono tracking-tight border transition-all ${
            loading
              ? "bg-white/5 border-white/10 text-white/30 cursor-not-allowed"
              : !weatherData
              ? "bg-white/5 border-white/10 text-white/30 cursor-not-allowed"
              : "bg-cyan-500 border-transparent text-black font-semibold shadow-[0_0_15px_rgba(34,211,238,0.25)] hover:shadow-[0_0_25px_rgba(34,211,238,0.4)] hover:brightness-110 active:scale-[0.98]"
          }`}
        >
          {loading ? (
            <>
              <div className="w-3.5 h-3.5 rounded-full border-2 border-white/10 border-t-black animate-spin" />
              SYNTHESIZING...
            </>
          ) : (
            <>
              <MessageSquareCode className="w-4 h-4" />
              {insights ? "REFRESH AI SYNAPSE" : "EXECUTE COGNITIVE SYNAPSE"}
            </>
          )}
        </button>
      </div>

      {!insights && !loading ? (
        <div className="flex-1 flex flex-col items-center justify-center py-12 text-center max-w-sm mx-auto">
          <div className="p-4 rounded-full bg-white/5 border border-white/10 text-white/40 mb-4 animate-pulse">
            <Cpu className="w-8 h-8" />
          </div>
          <h3 className="text-sm font-sans font-medium text-white">Cognitive weather node is asleep</h3>
          <p className="text-xs text-white/40 mt-2 leading-relaxed">
            Execute the cognitive synapse to command Gemini to analyze the local atmospheric metrics of {weatherData?.cityName || "your city"} and construct hyper-personalized predictions.
          </p>
        </div>
      ) : loading ? (
        <div className="flex-1 flex flex-col items-center justify-center py-12">
          <div className="relative flex items-center justify-center mb-4">
            <div className="absolute w-12 h-12 rounded-full border border-cyan-500/30 animate-ping" />
            <div className="p-4 rounded-full bg-white/5 border border-cyan-500/40 text-cyan-400">
              <Cpu className="w-6 h-6 animate-spin" style={{ animationDuration: "10s" }} />
            </div>
          </div>
          <span className="text-xs font-mono text-white/60">CONNECTING TO GEMINI AIR-NET NODE...</span>
          <span className="text-[10px] font-mono text-white/30 mt-1 animate-pulse">ANALYZING GEOMETRICAL VECTORS & DEW POINTS</span>
        </div>
      ) : (
        <div className="flex-1 flex flex-col lg:flex-row gap-6">
          {/* Quick Query Selector list (Left side on large screens) */}
          <div className="flex lg:flex-col gap-2 overflow-x-auto lg:overflow-x-visible pb-2 lg:pb-0 shrink-0 w-full lg:w-64 border-b lg:border-b-0 lg:border-r border-white/5 lg:pr-4">
            {cards.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedPanel(c.id)}
                className={`flex items-center gap-3 px-4 py-3 rounded-2xl border text-left transition-all shrink-0 lg:shrink-1 ${
                  selectedPanel === c.id
                    ? "bg-white/10 border-white/20 text-white shadow-[0_0_15px_rgba(34,211,238,0.05)]"
                    : "bg-transparent border-transparent hover:border-white/10 text-white/50 hover:text-white"
                }`}
              >
                <div className="p-2 bg-white/5 border border-white/10 rounded-xl">
                  {c.icon}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-sans font-medium truncate">{c.title}</div>
                  <div className="text-[9px] font-mono text-white/30 truncate mt-0.5">{c.query}</div>
                </div>
              </button>
            ))}
          </div>

          {/* Structured Insights Display Panel (Right side) */}
          <div className="flex-1 flex flex-col gap-4">
            {/* Severe Weather/Disaster Bulletins */}
            {insights?.disasterWarning && (
              <div className="p-4 bg-red-950/30 border border-red-500/30 rounded-2xl flex gap-3 items-start shadow-[0_0_15px_rgba(239,68,68,0.05)]">
                <AlertTriangle className="w-5 h-5 text-red-400 animate-pulse shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-mono font-bold text-red-400 uppercase tracking-widest">SEVERE ATMOSPHERE ALERT</h4>
                  <p className="text-xs text-red-300 font-sans mt-1 leading-relaxed">
                    {insights.disasterWarning}
                  </p>
                </div>
              </div>
            )}

            {/* AI Summary Banner */}
            <div className="p-5 bg-gradient-to-r from-cyan-950/20 to-teal-950/20 border border-cyan-500/20 rounded-2xl">
              <h4 className="text-[10px] font-mono text-cyan-400 tracking-widest uppercase mb-1.5 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                METEOROLOGICAL INSIGHT REPORT
              </h4>
              <p className="text-sm text-white/95 font-sans leading-relaxed italic">
                "{insights?.summary}"
              </p>
            </div>

            {/* Selected Panel Detail */}
            {activeCard && (
              <div className="flex-1 p-5 bg-white/5 border border-white/10 rounded-2xl flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-mono text-white/60 uppercase tracking-wider flex items-center gap-2 mb-3">
                    {activeCard.icon}
                    {activeCard.title}
                  </h4>
                  <p className="text-xs text-white/80 font-sans leading-relaxed whitespace-pre-wrap">
                    {activeCard.content || "Generating AI data vector..."}
                  </p>
                </div>

                <div className="border-t border-white/5 mt-4 pt-3 flex items-center justify-between text-[10px] font-mono text-white/30">
                  <span>METRIC INPUT VECTOR COMPILATION OK</span>
                  <span>PREDICTOR: CLIMATE-CORE-1.1</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Personalized report text overlay on bottom if available */}
      {insights?.personalizedReport && !loading && (
        <div className="mt-4 pt-3 border-t border-white/5 text-[11px] text-white/70 font-sans flex items-center gap-2">
          <span className="font-mono text-[9px] text-cyan-400 font-bold bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20 uppercase">
            Personal Report
          </span>
          <span className="italic">"{insights.personalizedReport}"</span>
        </div>
      )}
    </div>
  );
}
