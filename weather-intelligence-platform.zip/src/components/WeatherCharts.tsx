import React, { useState, useRef, useEffect } from "react";
import { HourlyForecastData, UserSettings } from "../types";
import { Thermometer, CloudRain, Wind, Gauge, Sun } from "lucide-react";

interface WeatherChartsProps {
  hourly: HourlyForecastData;
  settings: UserSettings;
}

export default function WeatherCharts({ hourly, settings }: WeatherChartsProps) {
  const [activeTab, setActiveTab] = useState<"temp" | "precipitation" | "humidity" | "pressure">("temp");
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // We take the first 24 hours of data for a pristine diurnal visualization
  const times = hourly.time.slice(0, 24);
  const temps = hourly.temperature_2m.slice(0, 24);
  const rainProb = hourly.precipitation_probability.slice(0, 24);
  const humidity = hourly.relative_humidity_2m.slice(0, 24);
  const pressure = hourly.pressure_msl.slice(0, 24);

  // Formatting helpers
  const formatTime = (isoString: string) => {
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });
  };

  const convertTemp = (celsius: number) => {
    if (settings.units === "imperial") {
      return Math.round((celsius * 9) / 5 + 32);
    }
    return Math.round(celsius);
  };

  // SVG Dimension setups
  const width = 800;
  const height = 280;
  const padding = 45;
  const chartWidth = width - padding * 2;
  const chartHeight = height - padding * 2;

  // Compute active dataset bounds
  let data: number[] = [];
  let color = "#3b82f6";
  let suffix = "";
  let glowColor = "rgba(59, 130, 246, 0.5)";

  if (activeTab === "temp") {
    data = temps.map((t) => convertTemp(t));
    color = settings.theme === "neon-cyber" ? "#f43f5e" : settings.theme === "matrix-green" ? "#22c55e" : "#06b6d4";
    suffix = settings.units === "metric" ? "°C" : "°F";
    glowColor = settings.theme === "neon-cyber" ? "rgba(244, 63, 94, 0.5)" : settings.theme === "matrix-green" ? "rgba(34, 197, 94, 0.5)" : "rgba(6, 182, 212, 0.5)";
  } else if (activeTab === "precipitation") {
    data = rainProb;
    color = "#0ea5e9";
    suffix = "%";
    glowColor = "rgba(14, 165, 233, 0.5)";
  } else if (activeTab === "humidity") {
    data = humidity;
    color = "#10b981";
    suffix = "%";
    glowColor = "rgba(16, 185, 129, 0.5)";
  } else if (activeTab === "pressure") {
    data = pressure;
    color = "#8b5cf6";
    suffix = " hPa";
    glowColor = "rgba(139, 92, 246, 0.5)";
  }

  const minVal = Math.min(...data);
  const maxVal = Math.max(...data);
  const valRange = maxVal - minVal === 0 ? 1 : maxVal - minVal;

  // Grid / coordinate generators
  const getCoordinates = () => {
    return data.map((val, idx) => {
      const x = padding + (idx / (data.length - 1)) * chartWidth;
      // Invert Y axis for screen space
      const y = padding + chartHeight - ((val - minVal) / valRange) * chartHeight;
      return { x, y, val, idx };
    });
  };

  const coords = getCoordinates();

  // Create curved bezier line path string
  const createSplinePath = () => {
    if (coords.length === 0) return "";
    let path = `M ${coords[0].x} ${coords[0].y}`;
    for (let i = 0; i < coords.length - 1; i++) {
      const curr = coords[i];
      const next = coords[i + 1];
      const cpX1 = curr.x + chartWidth / (coords.length - 1) / 2;
      const cpY1 = curr.y;
      const cpX2 = next.x - chartWidth / (coords.length - 1) / 2;
      const cpY2 = next.y;
      path += ` C ${cpX1} ${cpY1}, ${cpX2} ${cpY2}, ${next.x} ${next.y}`;
    }
    return path;
  };

  const createAreaPath = () => {
    const linePath = createSplinePath();
    if (!linePath) return "";
    // Connect to baseline
    return `${linePath} L ${coords[coords.length - 1].x} ${height - padding} L ${coords[0].x} ${height - padding} Z`;
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!containerRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const xPos = e.clientX - rect.left;
    // Calculate which index is closest to xPos
    const indexWidth = rect.width / 24;
    const approxIdx = Math.round((xPos - (padding / width) * rect.width) / (chartWidth / width * rect.width / 23));
    const clampedIdx = Math.max(0, Math.min(23, approxIdx));
    setHoverIndex(clampedIdx);
  };

  return (
    <div id="weather-dashboard-charts" className="glass rounded-3xl p-6 relative overflow-hidden shadow-2xl">
      {/* Decorative neon corner glow */}
      <div className="absolute -top-24 -right-24 w-48 h-48 rounded-full blur-[100px] opacity-25" style={{ backgroundColor: color }} />

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-sans font-medium text-white tracking-tight flex items-center gap-2">
            <span className="w-2 h-6 rounded-full" style={{ backgroundColor: color }} />
            Dynamic Atmospheric Trends
          </h2>
          <p className="text-xs text-white/40 font-mono mt-1">REAL-TIME TELEMETRY SCANNER</p>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-white/5 p-1 rounded-xl border border-white/10 overflow-x-auto w-full sm:w-auto">
          <button
            onClick={() => setActiveTab("temp")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono tracking-tight transition-all shrink-0 ${
              activeTab === "temp" ? "bg-white/10 text-white font-medium shadow" : "text-white/40 hover:text-white"
            }`}
          >
            <Thermometer className="w-3.5 h-3.5" style={{ color: activeTab === "temp" ? color : "inherit" }} />
            TEMP
          </button>
          <button
            onClick={() => setActiveTab("precipitation")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono tracking-tight transition-all shrink-0 ${
              activeTab === "precipitation" ? "bg-white/10 text-white font-medium shadow" : "text-white/40 hover:text-white"
            }`}
          >
            <CloudRain className="w-3.5 h-3.5" style={{ color: activeTab === "precipitation" ? color : "inherit" }} />
            RAIN %
          </button>
          <button
            onClick={() => setActiveTab("humidity")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono tracking-tight transition-all shrink-0 ${
              activeTab === "humidity" ? "bg-white/10 text-white font-medium shadow" : "text-white/40 hover:text-white"
            }`}
          >
            <Wind className="w-3.5 h-3.5" style={{ color: activeTab === "humidity" ? color : "inherit" }} />
            HUMIDITY
          </button>
          <button
            onClick={() => setActiveTab("pressure")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono tracking-tight transition-all shrink-0 ${
              activeTab === "pressure" ? "bg-white/10 text-white font-medium shadow" : "text-white/40 hover:text-white"
            }`}
          >
            <Gauge className="w-3.5 h-3.5" style={{ color: activeTab === "pressure" ? color : "inherit" }} />
            PRESSURE
          </button>
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div ref={containerRef} className="w-full relative overflow-x-auto select-none">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          width="100%"
          className="min-w-[650px] overflow-visible"
          onMouseMove={handleMouseMove}
          onMouseLeave={() => setHoverIndex(null)}
        >
          <defs>
            {/* Ambient Area Gradient Fill */}
            <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity="0.35" />
              <stop offset="100%" stopColor={color} stopOpacity="0.00" />
            </linearGradient>

            {/* Glowing neon line drop filter */}
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Grid Lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio, i) => {
            const y = padding + ratio * chartHeight;
            const gridVal = maxVal - ratio * valRange;
            return (
              <g key={i}>
                <line
                  x1={padding}
                  y1={y}
                  x2={width - padding}
                  y2={y}
                  stroke="rgba(255, 255, 255, 0.08)"
                  strokeWidth="1"
                  strokeDasharray="4 4"
                />
                <text
                  x={padding - 10}
                  y={y + 4}
                  fill="rgba(255, 255, 255, 0.4)"
                  fontSize="10"
                  fontFamily="monospace"
                  textAnchor="end"
                >
                  {Math.round(gridVal)}
                  {activeTab === "temp" && "°"}
                </text>
              </g>
            );
          })}

          {/* Horizontal X Axis Labels */}
          {coords.filter((_, i) => i % 3 === 0).map((pt, i) => (
            <text
              key={i}
              x={pt.x}
              y={height - padding + 20}
              fill="rgba(255, 255, 255, 0.4)"
              fontSize="10"
              fontFamily="monospace"
              textAnchor="middle"
            >
              {formatTime(times[pt.idx])}
            </text>
          ))}

          {/* Area under curve */}
          {coords.length > 0 && (
            <path d={createAreaPath()} fill="url(#areaGrad)" />
          )}

          {/* Spline Curve Line */}
          {coords.length > 0 && (
            <path
              d={createSplinePath()}
              fill="none"
              stroke={color}
              strokeWidth="2.5"
              filter="url(#glow)"
            />
          )}

          {/* Glowing node highlights on hover */}
          {coords.map((pt, idx) => (
            <circle
              key={idx}
              cx={pt.x}
              cy={pt.y}
              r={hoverIndex === idx ? "5" : "2"}
              fill={hoverIndex === idx ? color : "#ffffff"}
              stroke={color}
              strokeWidth={hoverIndex === idx ? "2.5" : "0"}
              className="transition-all duration-100 pointer-events-none"
              style={{ filter: hoverIndex === idx ? "drop-shadow(0 0 4px " + color + ")" : "none" }}
            />
          ))}

          {/* Vertical Scanner Guideline */}
          {hoverIndex !== null && coords[hoverIndex] && (
            <line
              x1={coords[hoverIndex].x}
              y1={padding}
              x2={coords[hoverIndex].x}
              y2={height - padding}
              stroke="#475569"
              strokeWidth="1.5"
              strokeDasharray="2 2"
              className="pointer-events-none animate-pulse"
            />
          )}
        </svg>

        {/* Hover Tooltip Overlay (absolute HTML for visual control and pixel-perfect text rendering) */}
        {hoverIndex !== null && coords[hoverIndex] && (
          <div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center pointer-events-none z-10"
            style={{
              left: `${((coords[hoverIndex].x - padding) / chartWidth) * 90 + 5}%`,
              top: `${(coords[hoverIndex].y / height) * 80 + 10}%`,
            }}
          >
            <div className="backdrop-blur-md bg-black/90 border border-white/10 rounded-xl p-3 shadow-xl flex flex-col gap-1 min-w-[120px] bg-dots">
              <span className="text-[10px] text-white/30 font-mono tracking-wider">
                TIME: {formatTime(times[hoverIndex])}
              </span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
                <span className="text-sm font-sans font-medium text-white">
                  {coords[hoverIndex].val}
                  {suffix}
                </span>
              </div>
              <span className="text-[9px] text-white/45 font-mono mt-0.5">
                CODE: {hourly.weather_code[hoverIndex]}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Atmospheric Insights summary banner under chart */}
      <div className="mt-6 pt-4 border-t border-white/5 flex flex-wrap gap-6 justify-between text-white/70">
        <div className="flex items-center gap-2">
          <Thermometer className="w-4 h-4 text-rose-400" />
          <div className="text-xs">
            <span className="text-white/35 font-mono">HIGH/LOW INTRADAY:</span>{" "}
            <span className="font-semibold text-white">
              {Math.max(...temps.map(t => convertTemp(t)))}{suffix}
            </span>
            {" / "}
            <span className="font-semibold text-white">
              {Math.min(...temps.map(t => convertTemp(t)))}{suffix}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <CloudRain className="w-4 h-4 text-sky-400" />
          <div className="text-xs">
            <span className="text-white/35 font-mono">RAIN RISK PEAK:</span>{" "}
            <span className="font-semibold text-white">{Math.max(...rainProb)}%</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Wind className="w-4 h-4 text-emerald-400" />
          <div className="text-xs">
            <span className="text-white/35 font-mono">AVG WIND VELOCITY:</span>{" "}
            <span className="font-semibold text-white">
              {Math.round(hourly.wind_speed_10m.slice(0, 24).reduce((a, b) => a + b, 0) / 24)} km/h
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
