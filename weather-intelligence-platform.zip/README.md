# Aura Meteorology Lab (v2.0)

Aura Meteorology Lab is a production-ready, enterprise-grade, full-stack weather forecasting and climate hazards intelligence platform. It features a stunning futuristic dark UI, adaptive particle physics backgrounds, custom SVG-glowing charting engines, interactive Leaflet world maps, and hyper-personalized climate summaries, travel, and health recommendations synthesized directly by **Gemini AI**.

---

## 🚀 Key Features

### 1. Futuristic Dark Dashboard
- **Glassmorphic Deck Design**: Styled with deep slates, glowing highlights, and micro-animations using Tailwind CSS and Framer Motion.
- **Adaptive Atmosphere Particles**: Renders floating wind currents, raindrops, snow crystals, or solar flares on an HTML5 canvas based on current local meteorological conditions and selected theme.
- **Three Deck Themes**: Choose between `Quantum Slate` (deep navy), `Neon Cyber` (cyberpunk rose), and `Matrix Green` (terminal emerald).

### 2. Multi-Metric Climate Telemetry
- Includes real-time readouts for temperature, relative humidity, wind speed & vector direction, barometric pressure, visibility distance, condensation dew point, and UV index.
- **US AQI Integration**: Provides real-time concentration metrics of fine particulates ($PM_{2.5}$, $PM_{10}$).

### 3. Interactive World Map
- Seamless interactive mapping engine utilizing custom-styled Leaflet.
- Fly-to animations for preset and saved sectors.
- Allows users to **click anywhere on Earth** to trigger reverse-geocoding coordinates and instantly pull full 14-day forecasts.

### 4. Custom SVG Analytics
- High-fidelity glowing line splines with area gradients and hover guides for hourly temperature trends.
- Responsive, clean visualization that avoids React 19 charting incompatibilities.

### 5. Gemini AI Core
- Powered by `gemini-3.5-flash` via the modern `@google/genai` TypeScript SDK.
- Translates atmospheric metrics into precise JSON recommendations for clothing, travel safety, agriculture/farming, outdoor fitness, and climate-hazard alerts.

### 6. Seismic and Hazard alerts
- Curated global seismic activities, tropical cyclones, space weather disruptions, and severe weather warnings with severity badges.

---

## 🛠️ Tech Stack & Architecture

- **Frontend**: React 19, TypeScript, Tailwind CSS, Framer Motion, Lucide Icons, Leaflet Maps.
- **Backend**: Node.js, Express.js (serving Vite as middleware in development and serving compiled static assets in production).
- **AI Engine**: `@google/genai` TypeScript SDK.
- **APIs (No Keys Required for Weather)**: 
  - [Open-Meteo](https://open-meteo.com) (Real-Time Forecasts, Air Quality, Geocoding)
  - [OpenStreetMap Nominatim](https://nominatim.org) (Reverse GPS Geocoding)

---

## 📂 Project Structure

```bash
├── .env.example            # Environment variables template
├── index.html              # HTML shell entrypoint
├── package.json            # Scripts and dependency manifests
├── server.ts               # Full-stack Express + Vite Middleware server
├── vite.config.ts          # Vite bundler configurations
├── src/
│   ├── main.tsx            # Main React bootstrapper
│   ├── App.tsx             # Master reactive layout and state coordinator
│   ├── index.css           # Global Tailwind declarations and typography
│   ├── types.ts            # Type contracts, preset cities, and weather code maps
│   └── components/
│       ├── AiAdvisor.tsx   # Gemini AI insight advisor panel
│       ├── WeatherCharts.tsx # Custom glowing SVG charting component
│       ├── WeatherMap.tsx  # Leaflet mapping and click coordinates handler
│       ├── NewsFeed.tsx    # Seismic and extreme climate alert feed
│       └── BackgroundParticles.tsx # Adaptable weather-based particle effects
```

---

## ⚙️ Environment Variables

Create a `.env` file in the root directory. Copy and configure the following parameters:

```env
# GEMINI_API_KEY: Required for Gemini AI insights (summary, clothing, safety guides).
# Obtain this key from Google AI Studio.
GEMINI_API_KEY="YOUR_GEMINI_API_KEY"

# APP_URL: Self-referential URL where this applet is hosted.
# Used for mapping references and API proxies.
APP_URL="http://localhost:3000"
```

---

## 📦 Installation Guide

### Prerequisites
- Node.js (v18.x or higher)
- npm (v9.x or higher)

### Setup Steps
1. Clone the project or extract the workspace files.
2. Open a terminal in the root directory and install dependencies:
   ```bash
   npm install
   ```
3. Establish your environment secrets by creating `.env` from `.env.example`:
   ```bash
   cp .env.example .env
   ```
4. Put your valid Gemini API Key into the `.env` file.
5. Launch the local full-stack development server:
   ```bash
   npm run dev
   ```
6. Open your browser and navigate to `http://localhost:3000` to interact with the platform.

---

## 📑 API Documentation

### 1. Geocoding Autocomplete Search
- **Endpoint**: `/api/weather/search`
- **Method**: `GET`
- **Query Parameter**: `q` (min 2 characters city name)
- **Response**: Array of candidate cities with coordinates, admin provinces, and country names.

### 2. Meteorological Forecast
- **Endpoint**: `/api/weather/forecast`
- **Method**: `GET`
- **Query Parameters**: 
  - `lat`: Latitude coordinate (decimal)
  - `lon`: Longitude coordinate (decimal)
  - `city`: (Optional) City name
- **Response**: Integrated Open-Meteo forecast (current conditions, hourly diurnal trends, 14-day daily grids) and current air quality index concentration values.

### 3. Gemini Cognitive Insights
- **Endpoint**: `/api/weather/ai-insights`
- **Method**: `POST`
- **Request Body**: `{ weatherData: WeatherData }`
- **Response**: Structured JSON containing personalized reports, clothing advisories, travel ratings, health directives, and safety bulletins.

---

## 🌐 Deployment Guide

### Production Compilation
Before deploying, compile your TypeScript server and build your optimized production client bundle:
```bash
npm run build
```
This produces a self-contained CommonJS bundled server inside `dist/server.cjs` and client assets in `dist/`.

### Starting Production Server
Run the compiled server directly using Node:
```bash
npm start
```
The server will boot on port `3000` and handle static asset serving and SPA routing automatically.

### Docker Deployment
A typical Dockerfile to containerize this applet on platforms like Cloud Run:
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build
ENV NODE_ENV=production
EXPOSE 3000
CMD ["npm", "start"]
```

---

## 🧪 Testing & Verification Guide

### Linter Verification
Ensure that TypeScript types and imports comply with static specifications:
```bash
npm run lint
```

### Visual Verification
1. Launch the dev server.
2. Test searching for cities (e.g. "Paris", "New York") and ensure the autocomplete dropdown displays matching nodes.
3. Test the "GPS Auto Detect" button and verify your browser prompts for Location permission.
4. Test clicking on various coordinates across continents on the Leaflet map and check if the selected city panels fly to the location and update correctly.
5. Click on **"Execute Cognitive Synapse"** and verify that Gemini generates highly detailed recommendations and personal summaries for the selected city.

---

## 📄 License
This project is licensed under the Apache-2.0 License. See the header notices in individual source files for detail.
